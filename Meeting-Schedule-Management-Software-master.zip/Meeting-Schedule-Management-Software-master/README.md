# Meeting-Schedule-Management-Software

Planning for meeting, managing it and conducting it strategically to achieve a solid outcome from the meeting is all part of Meeting Management System.
This project developed using C#.NET and Microsoft Access Driver

For more information and updates about this project:
https://www.studentprojects.live/studentprojectreport/projectreport/meeting-management-system/
